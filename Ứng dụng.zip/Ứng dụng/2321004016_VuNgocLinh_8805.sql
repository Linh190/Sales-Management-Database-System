﻿CREATE DATABASE QLBHDMX
USE QLBHDMX
GO

-- 1. BẢNG BỘ PHẬN
CREATE TABLE BoPhan(
	MABP nvarchar(20) NOT NULL PRIMARY KEY,
	TENBP nvarchar(30)
);

-- 2. BẢNG CHỨC VỤ
CREATE TABLE ChucVu(
	MACV nvarchar(20) NOT NULL PRIMARY KEY,
	TENCV nvarchar(30)
);

-- 3. BẢNG KHÁCH HÀNG
CREATE TABLE KhachHang(
	MAKH nvarchar(20) NOT NULL PRIMARY KEY,
	TENKH nvarchar(50),
	DIACHIKH nvarchar(200),
	DIENTHOAIKH varchar(11),
	EMAILKH varchar(200)
);

-- 4. BẢNG LOẠI SẢN PHẨM 
CREATE TABLE LoaiSanPham(
	MALOAISP nvarchar(20) NOT NULL PRIMARY KEY,
	TENLOAISP nvarchar(50)
);

-- 5. BẢNG NHÓM SẢN PHẨM
CREATE TABLE NhomSanPham(
	MANHOMSP nvarchar(20) NOT NULL PRIMARY KEY,
	TENNHOMSP nchar(100)
);

-- 6.  BẰNG MATHANG
CREATE TABLE MatHang(
	MAMH nvarchar(50) NOT NULL PRIMARY KEY,
	TENMH nvarchar(100),
	GIAMH float,
	SOLUONGMH float,
	MALOAISP nvarchar(20),
	MANHOMSP nvarchar(20),

	FOREIGN KEY (MALOAISP) REFERENCES LoaiSanPham(MALOAISP),
	FOREIGN KEY (MANHOMSP) REFERENCES NhomSanPham(MANHOMSP)
);

-- 7. BẢNG NHÂN VIÊN
CREATE TABLE NhanVien(
	MANV nvarchar(20) NOT NULL PRIMARY KEY,
	TENNV nvarchar(100),
	NGAYSINHNV datetime,
	GIOITINHNV bit,
	DIACHINV nvarchar(200),
	SDTNV varchar(11),
	TENDANGNHAP nvarchar(20),
	MATKHAU nvarchar(20),
	NGAYDANGKYNV datetime,
	MABP nvarchar(20),
	MACV nvarchar(20),

	FOREIGN KEY (MABP) REFERENCES BoPhan(MABP),
	FOREIGN KEY (MACV) REFERENCES ChucVu(MACV)
);

-- 8. BẢNG HÓA ĐƠN
CREATE TABLE HoaDon(
	MAHD nvarchar(20) NOT NULL PRIMARY KEY,
	NGAYHD datetime,
	THANHTIEN float,
	MAKH nvarchar(20),
	MANV nvarchar(20),
	FOREIGN KEY (MAKH) REFERENCES KhachHang(MAKH),
	FOREIGN KEY (MANV) REFERENCES NhanVien(MANV)
);

-- 9. BẢNG CHI TIẾT HÓA ĐƠN (DÙNG MẶT HÀNG MỚI)
CREATE TABLE ChiTietHoaDon(
	MAHD nvarchar(20) NOT NULL,
	MAMH nvarchar(50) NOT NULL,
	SOLUONGHD int,
	DONGIAHD float,
	THANHTIENHD float,
	CHIETKHAU float,
	PRIMARY KEY (MAHD, MAMH),

	FOREIGN KEY (MAHD) REFERENCES HoaDon(MAHD),
	FOREIGN KEY (MAMH) REFERENCES MatHang(MAMH)
);

-- 10. BẢNG NHÀ CUNG CẤP
CREATE TABLE NhaCungCap(
	MANCC nvarchar(20) NOT NULL PRIMARY KEY,
	TENNCC nvarchar(100),
	DIACHINCC nvarchar(200),
	SDTNCC varchar(11),
	EMAILNCC varchar(200)
);

-- 11. PHIẾU NHẬP KHO
CREATE TABLE PhieuNhap(
	MAPN nvarchar(20) NOT NULL PRIMARY KEY,
	NGAYNHAP datetime,
	MANCC nvarchar(20),
	MANV nvarchar(20),

	FOREIGN KEY (MANCC) REFERENCES NhaCungCap(MANCC),
	FOREIGN KEY (MANV) REFERENCES NhanVien(MANV)
);

-- 12. CHI TIẾT PHIẾU NHẬP
CREATE TABLE ChiTietPhieuNhap(
	MAPN nvarchar(20) NOT NULL,
	MAMH nvarchar(50) NOT NULL,
	SOLUONG int,
	DONGIA float,
	THANHTIEN float,

	PRIMARY KEY (MAPN, MAMH),
	FOREIGN KEY (MAPN) REFERENCES PhieuNhap(MAPN),
	FOREIGN KEY (MAMH) REFERENCES MatHang(MAMH)
);

-- 13. PHIẾU XUẤT
CREATE TABLE PhieuXuat(
	MAPX nvarchar(20) NOT NULL PRIMARY KEY,
	NGAYXUAT datetime,
	MANV nvarchar(20),

	FOREIGN KEY (MANV) REFERENCES NhanVien(MANV)
);

-- 14. CHI TIẾT PHIẾU XUẤT
CREATE TABLE ChiTietPhieuXuat(
	MAPX nvarchar(20) NOT NULL,
	MAMH nvarchar(50) NOT NULL,
	SOLUONG int,
	DONGIA float,
	THANHTIEN float,

	PRIMARY KEY (MAPX, MAMH),
	FOREIGN KEY (MAPX) REFERENCES PhieuXuat(MAPX),
	FOREIGN KEY (MAMH) REFERENCES MatHang(MAMH)
);
-- Bảng log/audit để trigger ghi nhận thay đổi
CREATE TABLE Audit_Log(
    AuditID INT IDENTITY(1,1) PRIMARY KEY,
    EventTime DATETIME DEFAULT GETDATE(),
    EventType NVARCHAR(50),
    TableName NVARCHAR(100),
    KeyValues NVARCHAR(400),
    Detail NVARCHAR(MAX),
    PerformedBy NVARCHAR(100)
);
GO

-- 1. BoPhan 
INSERT INTO BoPhan(MABP, TENBP) VALUES
('BP001', N'Phòng Kinh doanh'),
('BP002', N'Phòng Kế toán'),
('BP003', N'Phòng Kỹ thuật - Bảo hành'),
('BP004', N'Phòng Kho vận'),
('BP005', N'Ban Giám đốc');

-- 2. ChucVu
INSERT INTO ChucVu(MACV, TENCV) VALUES
('CV001', N'Giám đốc'),
('CV002', N'Phó giám đốc'),
('CV003', N'Trưởng phòng'),
('CV004', N'Nhân viên kinh doanh'),
('CV005', N'Nhân viên kho'),
('CV006', N'Kế toán trưởng');

-- 3. NhanVien 
INSERT INTO NhanVien(MANV,TENNV,NGAYSINHNV,GIOITINHNV,DIACHINV,SDTNV,TENDANGNHAP,MATKHAU,NGAYDANGKYNV,MABP,MACV) VALUES
('NV001', N'Nguyễn Văn Huy', '1988-03-15', 1, N'123 Lê Lợi, Q.1, TP.HCM', '0903123456', 'huy.nv', 'Huy@2025', '2020-01-10', 'BP005', 'CV001'),
('NV002', N'Trần Thị Mai Anh', '1990-07-22', 0, N'45 Nguyễn Trãi, Q.5, TP.HCM', '0918234567', 'anh.ttm', 'Anh@2025', '2020-02-20', 'BP001', 'CV003'),
('NV003', N'Lê Minh Tuấn', '1993-11-30', 1, N'78 Trần Hưng Đạo, Q.1, TP.HCM', '0935123789', 'tuan.lm', 'Tuan123', '2021-03-15', 'BP001', 'CV004'),
('NV004', N'Phạm Ngọc Lan', '1995-05-18', 0, N'56 CMT8, Q.3, TP.HCM', '0978456123', 'lan.pn', 'Lan@2025', '2021-06-20', 'BP001', 'CV004'),
('NV005', N'Hoàng Văn Nam', '1994-09-10', 1, N'89 Võ Văn Tần, Q.3, TP.HCM', '0987654321', 'nam.hv', 'Nam123', '2021-08-01', 'BP004', 'CV005'),
('NV006', N'Vũ Thị Hồng', '1996-12-25', 0, N'12 Nguyễn Thị Minh Khai, Q.1', '0909876543', 'hong.vt', 'Hong@2025', '2022-01-10', 'BP002', 'CV006'),
('NV007', N'Đỗ Quang Vinh', '1992-04-05', 1, N'234 Hai Bà Trưng, Q.3', '0912345678', 'vinh.dq', 'Vinh123', '2022-03-20', 'BP001', 'CV004'),
('NV008', N'Bùi Thị Thảo', '1997-08-14', 0, N'67 Lý Tự Trọng, Q.1', '0938765432', 'thao.bt', 'Thao@2025', '2023-01-05', 'BP001', 'CV004'),
('NV009', N'Nguyễn Hoàng Long', '1991-06-30', 1, N'89 Pasteur, Q.3', '0905566778', 'long.nh', 'Long123', '2020-05-15', 'BP003', 'CV003'),
('NV010', N'Trịnh Minh Châu', '1995-02-28', 0, N'45 Điện Biên Phủ, Q.Bình Thạnh', '0981122333', 'chau.tm', 'Chau@2025', '2023-06-10', 'BP001', 'CV004'),
('NV011', N'Phan Văn Khánh', '1994-10-12', 1, N'112 Nguyễn Đình Chiểu, Q.3', '0919988777', 'khanh.pv', 'Khanh123', '2023-09-01', 'BP004', 'CV005'),
('NV012', N'Lý Thị Kim Ngân', '1993-01-20', 0, N'78/12 Lê Văn Sỹ, Q.Phú Nhuận', '0903344556', 'ngan.ltk', 'Ngan@2025', '2022-11-15', 'BP002', 'CV004'),
('NV013', N'Nguyễn Thị Phương Thảo', '1996-03-12', 0, N'89/12 Nguyễn Hữu Cảnh, Q.Bình Thạnh', '0908456123', 'thao.ntp', 'Thao2025', '2023-02-15', 'BP001', 'CV004'),
('NV014', N'Trần Quốc Bảo', '1993-08-25', 1, N'123 Lê Đại Hành, Q.11', '0917567890', 'bao.tq', 'Bao123', '2022-07-20', 'BP001', 'CV004'),
('NV015', N'Phạm Minh Đức', '1995-11-18', 1, N'56/3 Nguyễn Sơn, Q.Tân Phú', '0938678901', 'duc.pm', 'Duc@2025', '2023-04-10', 'BP004', 'CV005'),
('NV016', N'Hà Thị Ngọc Ánh', '1997-05-30', 0, N'78/5 Lê Văn Sỹ, Q.3', '0981123456', 'anh.htn', 'AnhNgoc123', '2023-08-01', 'BP001', 'CV004'),
('NV017', N'Đinh Văn Hùng', '1992-09-14', 1, N'45 Trần Phú, Q.5', '0909988776', 'hung.dv', 'Hung2025', '2021-11-15', 'BP003', 'CV003'),
('NV018', N'Lê Thị Diễm My', '1998-01-27', 0, N'234 Nguyễn Thị Thập, Q.7', '0912233445', 'my.ltd', 'My123', '2024-01-20', 'BP001', 'CV004'),
('NV019', N'Võ Hoàng Long', '1994-07-08', 1, N'67/2 Phạm Ngọc Thạch, Q.3', '0935566778', 'long.vh', 'LongVH2025', '2022-09-10', 'BP004', 'CV005'),
('NV020', N'Nguyễn Thị Kim Oanh', '1996-12-03', 0, N'112 Nguyễn Đình Chiểu, Q.3', '0903344557', 'oanh.ntk', 'Oanh@2025', '2023-10-05', 'BP002', 'CV004'),
('NV021', N'Trần Văn Khánh', '1991-04-19', 1, N'89/5B Cách Mạng Tháng 8, Q.10', '0916677889', 'khanh.tv', 'Khanh123', '2021-05-12', 'BP001', 'CV004'),
('NV022', N'Phan Thị Hồng Nhung', '1997-10-22', 0, N'45/7A Nguyễn Trãi, Q.5', '0987788990', 'nhung.pth', 'Nhung2025', '2024-03-01', 'BP001', 'CV004'),
('NV023', N'Huỳnh Minh Triết', '1993-06-15', 1, N'78/9 Lý Thường Kiệt, Q.Tân Bình', '0905566779', 'triet.hm', 'Triet123', '2022-12-18', 'BP004', 'CV005'),
('NV024', N'Bùi Thị Thanh Thảo', '1995-02-28', 0, N'123/4B Nguyễn Văn Cừ, Q.5', '0938899001', 'thao.btt', 'ThaoBui2025', '2023-07-25', 'BP001', 'CV004'),
('NV025', N'Đỗ Hoàng Anh', '1994-11-11', 1, N'56/2C Lê Lợi, Q.1', '0918899002', 'anh.dh', 'AnhDo2025', '2022-06-30', 'BP001', 'CV004'),
('NV026', N'Nguyễn Thị Minh Thư', '1998-08-17', 0, N'89/3D Trần Hưng Đạo, Q.1', '0907788991', 'thu.ntm', 'Thu123', '2024-02-10', 'BP001', 'CV004'),
('NV027', N'Lê Văn Tuấn Kiệt', '1992-03-05', 1, N'234/5E Võ Văn Tần, Q.3', '0936677880', 'kiet.lvt', 'Kiet2025', '2021-09-20', 'BP003', 'CV003'),
('NV028', N'Trần Thị Bích Ngọc', '1996-09-30', 0, N'45/6F Nguyễn Thị Minh Khai, Q.1', '0986677881', 'ngoc.ttb', 'Ngoc2025', '2023-11-15', 'BP002', 'CV004'),
('NV029', N'Phạm Quốc Huy', '1993-12-25', 1, N'78/7G Nguyễn Huệ, Q.1', '0906677882', 'huy.pq', 'HuyPham123', '2022-08-05', 'BP001', 'CV004'),
('NV030', N'Vũ Thị Lan Hương', '1997-07-14', 0, N'112/8H Điện Biên Phủ, Q.Bình Thạnh', '0915566770', 'huong.vtl', 'Huong2025', '2024-04-20', 'BP001', 'CV004');
-- 4. KhachHang 
INSERT INTO KhachHang(MAKH,TENKH,DIACHIKH,DIENTHOAIKH,EMAILKH) VALUES
('KH001', N'Trần Văn Nam', N'56 Nguyễn Văn Cừ, Q.5, TP.HCM', '0908111222', 'namtv@gmail.com'),
('KH002', N'Nguyễn Thị Lan', N'123 Lê Văn Việt, Q.9, TP.HCM', '0919222333', 'lannt@gmail.com'),
('KH003', N'Phạm Quốc Bảo', N'89 Trường Chinh, Tân Bình', '0933444555', 'bao.pq@gmail.com'),
('KH004', N'Lê Thị Thu Hà', N'45/12 Quang Trung, Gò Vấp', '0987654321', 'haltt@gmail.com'),
('KH005', N'Huỳnh Văn Tuấn', N'78 Nguyễn Tri Phương, Q.10', '0905566778', 'tuanhv@gmail.com'),
('KH006', N'Công ty TNHH MTV Sài Gòn Xanh', N'112 Cách Mạng Tháng 8, Q.3', '02873005566', 'info@saigonxanh.vn'),
('KH007', N'Vũ Minh Quân', N'234 Lê Hồng Phong, Q.5', '0912345678', 'quanvm@gmail.com'),
('KH008', N'Đặng Thị Kim Chi', N'56/7 Phạm Văn Đồng, Thủ Đức', '0938765432', 'chibtk@gmail.com'),
('KH009', N'Nguyễn Anh Khoa', N'89/12 Nguyễn Thái Học, Q.1', '0909876543', 'khoana@gmail.com'),
('KH010', N'Trần Hoàng Yến', N'45/6A Lý Thường Kiệt, Q.Tân Bình', '0981122334', 'yenth@gmail.com'),
('KH011', N'Đỗ Quang Huy', N'78 Nguyễn Thị Thập, Q.7', '0913344556', 'huydq@gmail.com'),
('KH012', N'Phan Thị Ngọc Ánh', N'123 Xa lộ Hà Nội, Q.2', '0902233445', 'anhptn@gmail.com'),
('KH013', N'Công ty CP Điện máy Việt', N'567 Nguyễn Văn Linh, Q.7', '02837778888', 'contact@dienmayviet.vn'),
('KH014', N'Lê Văn Hùng', N'89/12C Lê Đại Hành, Q.11', '0935678901', 'hunglv@gmail.com'),
('KH015', N'Trịnh Thị Mai', N'45/3 Nguyễn Sơn, Tân Phú', '0907788990', 'maitt@gmail.com');
INSERT INTO KhachHang(MAKH,TENKH,DIACHIKH,DIENTHOAIKH,EMAILKH) VALUES
('KH016', N'Nguyễn Thị Hồng Nhung', N'89/12 Nguyễn Oanh, Gò Vấp', '0908123456', 'nhungnth@gmail.com'),
('KH017', N'Trần Minh Hoàng', N'123/4B Phạm Văn Đồng, Thủ Đức', '0919234567', 'hoangtm@gmail.com'),
('KH018', N'Lê Thị Kim Ngân', N'56/7 Quang Trung, Q.12', '0934567890', 'nganltk@gmail.com'),
('KH019', N'Phạm Văn Dũng', N'78/3A Lê Văn Việt, Q.9', '0987654322', 'dungpv@gmail.com'),
('KH020', N'Huỳnh Thị Thu Trang', N'45/5B Nguyễn Thái Sơn, Gò Vấp', '0909876544', 'tranghtt@gmail.com'),
('KH021', N'Công ty TNHH Xây dựng An Phát', N'234 CMT8, Q.10', '02838654321', 'info@anphat.vn'),
('KH022', N'Đặng Văn Tuấn', N'67/2B Hoàng Diệu, Q.4', '0913456789', 'tuandv@gmail.com'),
('KH023', N'Nguyễn Thị Diễm', N'89/4C Trường Sơn, Tân Bình', '0936789012', 'diemnt@gmail.com'),
('KH024', N'Võ Minh Khang', N'112/6D Nguyễn Xí, Bình Thạnh', '0905678901', 'khangvm@gmail.com'),
('KH025', N'Trần Thị Phương Linh', N'45/8E An Dương Vương, Q.5', '0989012345', 'linhttp@gmail.com'),
('KH026', N'Lê Hoàng Nam', N'78/10F Nguyễn Kiệm, Phú Nhuận', '0918901234', 'namlh@gmail.com'),
('KH027', N'Phan Thị Mai Anh', N'123/12G Lê Quang Định, Bình Thạnh', '0907890123', 'anhptm@gmail.com'),
('KH028', N'Hà Văn Bình', N'56/14H Tân Kỳ Tân Quý, Tân Phú', '0938901234', 'binhhv@gmail.com'),
('KH029', N'Nguyễn Thị Tuyết Mai', N'89/16I Bùi Đình Túy, Bình Thạnh', '0906789012', 'maintt@gmail.com'),
('KH030', N'Trần Quốc Cường', N'234/18J Lũy Bán Bích, Tân Phú', '0915678901', 'cuongtq@gmail.com'),
('KH031', N'Công ty CP Thiết bị Điện Nam Việt', N'567 Nguyễn Oanh, Gò Vấp', '02838901234', 'sales@namviet.com.vn'),
('KH032', N'Đỗ Thị Thanh Huyền', N'78/20K Nguyễn Lâm, Q.7', '0904567890', 'huyendtt@gmail.com'),
('KH033', N'Nguyễn Văn Hiếu', N'45/22L Thống Nhất, Gò Vấp', '0935678902', 'hieunv@gmail.com'),
('KH034', N'Vũ Thị Kim Loan', N'112/24M Nguyễn Văn Đậu, Bình Thạnh', '0986789013', 'loanutk@gmail.com'),
('KH035', N'Hoàng Minh Tuấn', N'89/26N Âu Cơ, Tân Bình', '0905678903', 'tuanhm@gmail.com');
-- 5. LoaiSanPham & NhomSanPham
INSERT INTO LoaiSanPham(MALOAISP, TENLOAISP) VALUES
('LSP001', N'Điện lạnh'),
('LSP002', N'Điện gia dụng'),
('LSP003', N'Điện tử'),
('LSP004', N'Đồ gia dụng nhà bếp'),
('LSP005', N'Điện thoại - Tablet'),
('LSP006', N'Laptop - Máy tính'),
('LSP007', N'Phụ kiện điện tử'),
('LSP008', N'Máy nước nóng'),
('LSP009', N'Quạt điện'),
('LSP010', N'Máy phát điện - UPS');
INSERT INTO NhomSanPham(MANHOMSP, TENNHOMSP) VALUES
('NHOM001', N'Tủ lạnh'),
('NHOM002', N'Máy giặt'),
('NHOM003', N'Điều hòa'),
('NHOM004', N'Tivi'),
('NHOM005', N'Máy lọc nước'),
('NHOM006', N'Nồi cơm điện'),
('NHOM007', N'Lò vi sóng'),
('NHOM008', N'Điện thoại thông minh'),
('NHOM009', N'Laptop văn phòng'),
('NHOM010', N'Tai nghe - Loa'),
('NHOM011', N'Máy nước nóng năng lượng mặt trời'),
('NHOM012', N'Quạt đứng - treo tường'),
('NHOM013', N'Máy xay sinh tố'),
('NHOM014', N'Bếp từ - hồng ngoại'),
('NHOM015', N'Máy sấy tóc');
-- 6. NhaCungCap
INSERT INTO NhaCungCap(MANCC,TENNCC,DIACHINCC,SDTNCC,EMAILNCC) VALUES
('NCC001', N'Điện máy Xanh - CN TP.HCM', N'180 Cao Lỗ, Q.8, TP.HCM', '02873003333', 'cskh@dienmayxanh.com'),
('NCC002', N'Công ty CP Aqua Việt Nam', N'KCN Tân Tạo, Bình Tân, TP.HCM', '02837542888', 'info@aqua.com.vn'),
('NCC003', N'Công ty TNHH Samsung Electronics VN', N'KCN Sài Gòn, Q.9', '1800588889', 'support@samsung.com'),
('NCC004', N'Công ty CP Điện tử LG Việt Nam', N'KCN Tân Bình, TP.HCM', '18001503', 'lgcare@lge.com'),
('NCC005', N'Công ty TNHH Panasonic Việt Nam', N'KCN Thăng Long, Hà Nội', '18001596', 'support@panasonic.vn'),
('NCC006', N'Điện máy Chợ Lớn', N'512 Lê Hồng Phong, Q.10', '02838625252', 'info@cholon.com.vn'),
('NCC007', N'Công ty CP Thế Giới Di Động', N'222B Lê Duẩn, Q.1', '18001060', 'cskh@thegioididong.com'),
('NCC008', N'Công ty TNHH Điện máy MediaMart', N'123 Nguyễn Thị Minh Khai, Q.1', '1900555581', 'hotro@mediamart.vn'),
('NCC009', N'Công ty TNHH Điện máy HC', N'456 Lê Văn Sỹ, Q.3, TP.HCM', '02838484848', 'info@hcdienmay.vn'),
('NCC010', N'Công ty CP FPT Shop', N'261 Khánh Hội, Q.4', '18006601', 'hotro@fptshop.com.vn'),
('NCC011', N'Công ty TNHH Điện máy Thiên Nam Hòa', N'578 Nguyễn Kiệm, Phú Nhuận', '02839973888', 'cskh@thiennamhoa.vn'),
('NCC012', N'Công ty CP Thế Giới Điện Máy', N'123 Nguyễn Thị Minh Khai, Q.1', '18001088', 'info@thegioidienmay.vn'),
('NCC013', N'Công ty TNHH MTV Điện máy Pico', N'789 CMT8, Q.10', '18006606', 'support@pico.vn'),
('NCC014', N'Công ty CP Điện máy Nguyễn Kim', N'63-65 Trần Hưng Đạo, Q.1', '02838227888', 'cskh@nguyenkim.com'),
('NCC015', N'Công ty TNHH Điện máy Việt Long', N'234 Âu Cơ, Tân Bình', '02838181818', 'info@vietlong.com.vn');
-- 7. MatHang 
INSERT INTO MatHang(MAMH,TENMH,GIAMH,SOLUONGMH,MALOAISP,MANHOMSP) VALUES
('MH001', N'Tủ lạnh Samsung Inverter 208 lít RT19M300BGS/SV', 8990000, 25, 'LSP001', 'NHOM001'),
('MH002', N'Tủ lạnh LG Inverter 255 lít GN-B272PS', 10990000, 18, 'LSP001', 'NHOM001'),
('MH003', N'Máy giặt Panasonic 10kg NA-F100A4HRV', 8990000, 32, 'LSP002', 'NHOM002'),
('MH004', N'Máy giặt Samsung Inverter 9kg WW90T3040WW/SV', 8990000, 28, 'LSP002', 'NHOM002'),
('MH005', N'Điều hòa Daikin Inverter 9000 BTU FTKY25WAVM', 11990000, 15, 'LSP001', 'NHOM003'),
('MH006', N'Điều hòa Panasonic 1 chiều 12000 BTU CU/CS-N12WKH-8', 10990000, 20, 'LSP001', 'NHOM003'),
('MH007', N'Tivi Samsung 55 inch 4K Crystal UHD UA55DU8000', 13990000, 12, 'LSP003', 'NHOM004'),
('MH008', N'Tivi LG 65 inch OLED 4K OLED65C4PSA', 49990000, 5, 'LSP003', 'NHOM004'),
('MH009', N'Máy lọc nước RO Karofi K9IQ-2', 7990000, 40, 'LSP002', 'NHOM005'),
('MH010', N'Nồi cơm điện tử Panasonic 1.8 lít SR-CL188WRA', 2490000, 50, 'LSP004', 'NHOM006'),
('MH011', N'Lò vi sóng Sharp 25 lít R-G371XVN-BK', 2390000, 35, 'LSP004', 'NHOM007'),
('MH012', N'Tủ lạnh Hitachi Inverter 569 lít R-FW690PGV7X', 28990000, 8, 'LSP001', 'NHOM001'),
('MH013', N'Máy giặt LG Inverter 12kg FV1412S3BA', 13990000, 15, 'LSP002', 'NHOM002'),
('MH014', N'Điều hòa Casper Inverter 18000 BTU GC-18IS33', 10990000, 22, 'LSP001', 'NHOM003'),
('MH015', N'Tivi Sony 75 inch 4K KD-75X80L', 28990000, 7, 'LSP003', 'NHOM004'),
('MH016', N'Máy lọc nước Kangaroo KG110H', 5990000, 45, 'LSP002', 'NHOM005'),
('MH017', N'Nồi cơm điện Cuckoo 1.8 lít CR-1020F', 3990000, 30, 'LSP004', 'NHOM006'),
('MH018', N'Lò vi sóng Panasonic 27 lít NN-ST65JWYTE', 3490000, 28, 'LSP004', 'NHOM007'),
('MH019', N'Tủ lạnh Aqua Inverter 260 lít AQR-T299FA', 8990000, 20, 'LSP001', 'NHOM001'),
('MH020', N'Máy giặt Electrolux 10kg EWF1024BDWA', 11990000, 18, 'LSP002', 'NHOM002'),
('MH021', N'Điều hòa Funiki 9000 BTU HSC09TMU', 5990000, 35, 'LSP001', 'NHOM003'),
('MH022', N'Tivi TCL 55 inch 4K QLED 55C655', 11990000, 25, 'LSP003', 'NHOM004'),
('MH023', N'Tủ đông Sanaky 400 lít VH-4099A3', 9990000, 12, 'LSP001', 'NHOM001'),
('MH024', N'Máy giặt sấy LG 10.5kg FV1450H2B', 18990000, 8, 'LSP002', 'NHOM002'),
('MH025', N'Điều hòa LG Inverter 24000 BTU V24ENF', 18990000, 10, 'LSP001', 'NHOM003'),
('MH026', N'Tivi Xiaomi A Pro 65 inch 4K', 12990000, 20, 'LSP003', 'NHOM004'),
('MH027', N'Nồi cơm điện tử Tefal RK732168 1.8 lít', 1890000, 40, 'LSP004', 'NHOM006'),
('MH028', N'Lò vi sóng Electrolux EMG23K22B 23 lít', 2790000, 32, 'LSP004', 'NHOM007'),
('MH029', N'Máy lọc nước A.O.Smith 5 lõi', 6990000, 38, 'LSP002', 'NHOM005'),
('MH030', N'Tủ lạnh Toshiba Inverter 330 lít GR-RT416WE', 11990000, 15, 'LSP001', 'NHOM001'),
('MH031', N'Điện thoại iPhone 16 Pro Max 256GB', 34990000, 12, 'LSP005', 'NHOM008'),
('MH032', N'Điện thoại Samsung Galaxy S25 Ultra 512GB', 32990000, 10, 'LSP005', 'NHOM008'),
('MH033', N'Laptop Dell XPS 14 9440 (Intel Core Ultra 7)', 48990000, 8, 'LSP006', 'NHOM009'),
('MH034', N'Laptop ASUS ROG Strix G16 (RTX 4070)', 55990000, 6, 'LSP006', 'NHOM009'),
('MH035', N'Tai nghe AirPods Pro 2 (USB-C)', 6490000, 50, 'LSP007', 'NHOM010'),
('MH036', N'Loa Bluetooth JBL Charge 6', 4990000, 45, 'LSP007', 'NHOM010'),
('MH037', N'Máy nước nóng Rossi Amore 20 lít', 2990000, 60, 'LSP008', 'NHOM011'),
('MH038', N'Quạt đứng Senko DTS1609', 890000, 80, 'LSP009', 'NHOM012'),
('MH039', N'Máy xay sinh tố Philips HR2223', 1590000, 70, 'LSP004', 'NHOM013'),
('MH040', N'Bếp từ đôi Kangaroo KG419i', 2990000, 55, 'LSP004', 'NHOM014'),
('MH041', N'Máy sấy tóc Panasonic EH-ND65', 990000, 90, 'LSP007', 'NHOM015'),
('MH042', N'Điện thoại Xiaomi 14T Pro 512GB', 16990000, 25, 'LSP005', 'NHOM008'),
('MH043', N'Laptop MacBook Air M3 15 inch 2025', 33990000, 10, 'LSP006', 'NHOM009'),
('MH044', N'Tai nghe Sony WH-1000XM6', 8990000, 30, 'LSP007', 'NHOM010'),
('MH045', N'Máy nước nóng Ferroli 30 lít', 3590000, 40, 'LSP008', 'NHOM011'),
('MH046', N'Quạt hộp Asia VY357890', 790000, 85, 'LSP009', 'NHOM012'),
('MH047', N'Bếp hồng ngoại Sunhouse SHD6017', 1290000, 65, 'LSP004', 'NHOM014'),
('MH048', N'Máy xay sinh tố đa năng Bluestone', 1390000, 75, 'LSP004', 'NHOM013'),
('MH049', N'Điện thoại OPPO Find X8 Pro', 25990000, 15, 'LSP005', 'NHOM008'),
('MH050', N'Laptop Lenovo ThinkPad X1 Carbon Gen 13', 52990000, 7, 'LSP006', 'NHOM009');
-- 8. PhieuNhap + ChiTietPhieuNhap 
INSERT INTO PhieuNhap(MAPN, NGAYNHAP, MANCC, MANV) VALUES
('PN001', '2025-01-15 09:30:00', 'NCC001', 'NV005'),
('PN002', '2025-02-20 14:20:00', 'NCC003', 'NV005'),
('PN003', '2025-03-10 10:15:00', 'NCC002', 'NV011'),
('PN004', '2025-04-05 16:45:00', 'NCC004', 'NV005'),
('PN005', '2025-05-12 08:00:00', 'NCC007', 'NV011'),
('PN006', '2025-06-18 11:20:00', 'NCC009', 'NV005'),
('PN007', '2025-07-05 15:40:00', 'NCC010', 'NV011'),
('PN008', '2025-08-12 09:10:00', 'NCC014', 'NV005'),
('PN009', '2025-09-20 13:55:00', 'NCC003', 'NV015'),
('PN010', '2025-10-01 10:30:00', 'NCC004', 'NV011'),
('PN011', '2025-10-15 14:20:00', 'NCC015', 'NV005'),
('PN012', '2025-11-01 08:45:00', 'NCC006', 'NV015'),
('PN013', '2025-11-10 16:10:00', 'NCC001', 'NV011'),
('PN014', '2025-11-18 11:00:00', 'NCC011', 'NV005'),
('PN015', '2025-11-22 09:30:00', 'NCC007', 'NV015');

INSERT INTO ChiTietPhieuNhap(MAPN, MAMH, SOLUONG, DONGIA, THANHTIEN) VALUES
('PN001','MH001',10,7800000,78000000),
('PN001','MH003',15,7800000,117000000),
('PN001','MH007',8,12500000,100000000),

('PN002','MH008',5,45000000,225000000),
('PN002','MH013',10,12500000,125000000),

('PN003','MH002',12,9500000,114000000),
('PN003','MH004',20,7800000,156000000),

('PN004','MH005',10,10500000,105000000),
('PN004','MH006',15,9800000,147000000),

('PN005','MH026',20,11000000,220000000),
('PN005','MH022',15,10500000,157500000),
('PN006','MH031',8,31000000,248000000),
('PN006','MH035',30,5800000,174000000),
('PN007','MH033',5,45000000,225000000),
('PN008','MH037',40,2600000,104000000),
('PN009','MH042',15,15000000,225000000),
('PN010','MH041',60,850000,51000000),
('PN011','MH044',20,8000000,160000000),
('PN012','MH039',50,1300000,65000000),
('PN013','MH050',4,48000000,192000000),
('PN014','MH036',35,4500000,157500000),
('PN015','MH032',10,29000000,290000000);

-- 9. HoaDon + ChiTietHoaDon 
INSERT INTO HoaDon(MAHD, NGAYHD, THANHTIEN, MAKH, MANV) VALUES
('HD202501001', '2025-01-18 10:25:00', 0, 'KH001', 'NV003'),
('HD202501002', '2025-01-20 14:30:00', 0, 'KH006', 'NV004'),
('HD202502003', '2025-02-15 09:15:00', 0, 'KH003', 'NV007'),
('HD202502004', '2025-02-28 16:45:00', 0, 'KH013', 'NV008'),
('HD202503005', '2025-03-10 11:20:00', 0, 'KH005', 'NV003'),
('HD202504006', '2025-04-02 13:55:00', 0, 'KH007', 'NV010'),
('HD202505007', '2025-05-05 17:30:00', 0, 'KH011', 'NV004'),
('HD202505008', '2025-05-20 10:10:00', 0, 'KH009', 'NV008'),
('HD202506009', '2025-06-12 10:15:00', 0, 'KH016', 'NV013'),
('HD202507010', '2025-07-08 14:30:00', 0, 'KH021', 'NV014'),
('HD202508011', '2025-08-20 09:45:00', 0, 'KH008', 'NV016'),
('HD202509012', '2025-09-15 16:20:00', 0, 'KH031', 'NV018'),
('HD202510013', '2025-10-05 11:10:00', 0, 'KH012', 'NV021'),
('HD202510014', '2025-10-18 13:40:00', 0, 'KH025', 'NV022'),
('HD202511015', '2025-11-03 17:55:00', 0, 'KH019', 'NV024'),
('HD202511016', '2025-11-11 10:25:00', 0, 'KH028', 'NV026'),
('HD202511017', '2025-11-15 15:30:00', 0, 'KH006', 'NV013'),
('HD202511018', '2025-11-20 12:00:00', 0, 'KH033', 'NV030'),
('HD202511019', '2025-11-21 09:20:00', 0, 'KH010', 'NV016'),
('HD202511020', '2025-11-23 18:45:00', 0, 'KH035', 'NV029');

UPDATE HD
SET HD.THANHTIEN = CT.Tong
FROM HoaDon HD
JOIN (
    SELECT MAHD, SUM(THANHTIENHD) AS Tong
    FROM ChiTietHoaDon
    GROUP BY MAHD
) CT ON HD.MAHD = CT.MAHD;

-- Chi tiết hóa đơn
INSERT INTO ChiTietHoaDon(MAHD,MAMH,SOLUONGHD,DONGIAHD,THANHTIENHD,CHIETKHAU) VALUES
('HD202501001','MH001',1,8990000,8990000,0),
('HD202501001','MH003',1,8990000,8990000,5),
('HD202501002','MH008',2,49990000,99980000,10),
('HD202501002','MH013',1,13990000,13990000,0),
('HD202502003','MH005',1,11990000,11990000,3),
('HD202502003','MH007',1,13990000,13990000,0),
('HD202502004','MH026',5,12990000,64950000,15),
('HD202503005','MH002',1,10990000,10990000,0),
('HD202503005','MH009',2,7990000,15980000,5),
('HD202504006','MH004',1,8990000,8990000,0),
('HD202504006','MH010',3,2490000,7470000,0),
('HD202505007','MH022',1,11990000,11990000,8),
('HD202505008','MH011',2,2390000,4780000,0),
('HD202505008','MH027',1,1890000,1890000,0),
('HD202506009','MH031',1,34990000,34990000,5),
('HD202507010','MH033',1,48990000,48990000,3),
('HD202508011','MH035',3,6490000,19470000,10),
('HD202509012','MH037',5,2990000,14950000,0),
('HD202510013','MH042',1,16990000,16990000,8),
('HD202510014','MH041',2,990000,1980000,0),
('HD202511015','MH044',1,8990000,8990000,0),
('HD202511016','MH036',4,4990000,19960000,5),
('HD202511017','MH050',1,52990000,52990000,10),
('HD202511018','MH039',3,1590000,4770000,0),
('HD202511019','MH032',1,32990000,32990000,7),
('HD202511020','MH027',5,1890000,9450000,15);

-- 10. PhieuXuat 
INSERT INTO PhieuXuat(MAPX, NGAYXUAT, MANV) VALUES
('PX001', '2025-03-20 14:30:00', 'NV005'),
('PX002', '2025-04-15 09:00:00', 'NV011'),
('PX003', '2025-05-10 16:20:00', 'NV005'),
('PX004', '2025-06-25 14:20:00', 'NV005'),
('PX005', '2025-07-30 10:10:00', 'NV011'),
('PX006', '2025-08-18 16:45:00', 'NV015'),
('PX007', '2025-09-22 11:30:00', 'NV005'),
('PX008', '2025-10-10 09:15:00', 'NV011'),
('PX009', '2025-11-05 13:40:00', 'NV015'),
('PX010', '2025-11-19 15:55:00', 'NV005');

INSERT INTO ChiTietPhieuXuat(MAPX,MAMH,SOLUONG,DONGIA,THANHTIEN) VALUES
('PX001','MH001',1,7800000,7800000),
('PX002','MH007',1,12500000,12500000),
('PX003','MH009',2,7000000,14000000),
('PX004','MH035',2,5800000,11600000),
('PX005','MH041',5,850000,4250000),
('PX006','MH036',3,4500000,13500000),
('PX007','MH039',4,1300000,5200000),
('PX008','MH027',6,1700000,10200000),
('PX009','MH037',3,2600000,7800000),
('PX010','MH001',1,7800000,7800000);

GO
CREATE SYNONYM s_MatHang FOR dbo.MatHang;
CREATE SYNONYM s_HoaDon FOR dbo.HoaDon;
CREATE SYNONYM s_ChiTietHD FOR dbo.ChiTietHoaDon;
GO


SELECT TOP 3 TENMH FROM s_MatHang;
SELECT TOP 3 MAHD, NGAYHD FROM s_HoaDon;
SELECT TOP 3 MAHD, MAMH FROM s_ChiTietHD;

GO
-- Index 
CREATE INDEX IDX_MatHang_SoLuong ON dbo.MatHang(SOLUONGMH);
CREATE INDEX IDX_HoaDon_Ngay ON dbo.HoaDon(NGAYHD);
CREATE INDEX IX_NhanVien_TenDangNhap ON dbo.NhanVien(TENDANGNHAP);
CREATE  INDEX IDX_ChiTietHD_MAMH ON dbo.ChiTietHoaDon(MAMH);
GO
--Kiểm thử INDEX: IDX_MatHang_SoLuong
SELECT * FROM MatHang WITH(INDEX(IDX_MatHang_SoLuong))
WHERE SOLUONGMH > 70;

SELECT * FROM MatHang
WHERE SOLUONGMH > 70;
--Kiểm thử INDEX: IDX_HoaDon_Ngay
SELECT * FROM HoaDon WITH(INDEX(IDX_HoaDon_Ngay))
WHERE NGAYHD BETWEEN '2025-01-01' AND '2025-5-31';

SELECT * FROM HoaDon
WHERE NGAYHD BETWEEN '2025-01-01' AND '2025-5-31';
--Kiểm thử INDEX: IX_NhanVien_TenDangNhap
SELECT * FROM NhanVien WITH(INDEX(IX_NhanVien_TenDangNhap))
WHERE TENDANGNHAP = 'nam.hv';

SELECT * FROM NhanVien
WHERE TENDANGNHAP = 'nam.hv';

--Kiểm thử INDEX: IDX_ChiTietHD_MAMH
SELECT * FROM ChiTietHoaDon WITH(INDEX(IDX_ChiTietHD_MAMH))
WHERE MAMH = 'MH001';

SELECT * FROM ChiTietHoaDon
WHERE MAMH = 'MH001';

-- 1) View danh sách hóa đơn kèm thông tin khách hàng + nhân viên
CREATE VIEW vw_DanhSachHoaDon_Details AS
SELECT h.MAHD, h.NGAYHD, h.THANHTIEN, 
       kh.MAKH, kh.TENKH, kh.DIENTHOAIKH,
       nv.MANV, nv.TENNV
FROM dbo.HoaDon h
LEFT JOIN dbo.KhachHang kh ON h.MAKH = kh.MAKH
LEFT JOIN dbo.NhanVien nv ON h.MANV = nv.MANV;
GO

-- 2) View thống kê doanh thu theo tháng 
CREATE VIEW vw_ThongKe_DoanhThu_TheoThang AS
SELECT YEAR(NGAYHD) AS Nam, MONTH(NGAYHD) AS Thang,
       COUNT(MAHD) AS SoHoaDon,
       SUM(THANHTIEN) AS TongDoanhThu
FROM dbo.HoaDon
GROUP BY YEAR(NGAYHD), MONTH(NGAYHD);
GO

-- 3) View top mặt hàng bán chạy 
CREATE VIEW vw_Top_MatHang_BanChay AS
SELECT TOP 100 PERCENT 
       c.MAMH, 
       m.TENMH, 
       SUM(c.SOLUONGHD) AS TongSoLuongBan
FROM dbo.ChiTietHoaDon c
JOIN dbo.MatHang m ON c.MAMH = m.MAMH
GROUP BY c.MAMH, m.TENMH
ORDER BY TongSoLuongBan DESC;
GO

-- 4) View tồn kho theo nhà cung cấp
CREATE VIEW vw_TonKho_TheoNCC AS
SELECT n.MANCC, n.TENNCC, mh.MAMH, mh.TENMH, mh.SOLUONGMH
FROM dbo.NhaCungCap n
JOIN (
    SELECT DISTINCT pn.MANCC, c.MAMH
    FROM dbo.PhieuNhap pn
    JOIN dbo.ChiTietPhieuNhap c ON pn.MAPN = c.MAPN
) t ON t.MANCC = n.MANCC
JOIN dbo.MatHang mh ON mh.MAMH = t.MAMH;
GO

-- 5) View danh sách nhân viên theo bộ phận
CREATE VIEW vw_NhanVien_TheoBoPhan AS
SELECT 
    nv.MANV, 
    nv.TENNV, 
    bp.MABP, 
    bp.TENBP, 
    nv.SDTNV
FROM dbo.NhanVien nv
LEFT JOIN dbo.BoPhan bp 
    ON nv.MABP = bp.MABP;
GO


--KIỂM THỬ VIEWS --
SELECT TOP 10 * FROM vw_DanhSachHoaDon_Details;
SELECT * FROM vw_ThongKe_DoanhThu_TheoThang;
SELECT TOP 20 * FROM vw_Top_MatHang_BanChay;
SELECT TOP 20 * FROM vw_TonKho_TheoNCC;
SELECT * FROM vw_NhanVien_TheoBoPhan;
GO
---------------------------------
--------------------------------
-- 1) function: tính giá sau giảm + VAT giả sử VAT 10%
CREATE FUNCTION dbo.fn_TinhGiaSauVAT
(
    @gia FLOAT,
    @chietkhau FLOAT
)
RETURNS FLOAT
AS
BEGIN
    DECLARE @giaSauChietKhau FLOAT = @gia * (1.0 - ISNULL(@chietkhau,0));
    DECLARE @vat FLOAT = 0.10;
    RETURN (@giaSauChietKhau * (1 + @vat));
END
GO

-- 2) Function: trả về tồn kho cho 1 nhà cung cấp
CREATE FUNCTION dbo.ufn_TonKhoTheoNCC(@mancc NVARCHAR(20))
RETURNS TABLE
AS
RETURN
(
    SELECT mh.MAMH, mh.TENMH, mh.SOLUONGMH
    FROM dbo.MatHang mh
    WHERE mh.MAMH IN (
        SELECT DISTINCT c.MAMH
        FROM dbo.PhieuNhap pn
        JOIN dbo.ChiTietPhieuNhap c ON pn.MAPN = c.MAPN
        WHERE pn.MANCC = @mancc
    )
);
GO
--3. Function table: Trả về danh sách mặt hàng theo nhóm sản phẩm
CREATE FUNCTION dbo.ufn_MatHangTheoNhom (@MANHOMSP NVARCHAR(20))
RETURNS TABLE
AS
RETURN
(
    SELECT MAMH, TENMH, GIAMH, SOLUONGMH
    FROM dbo.MatHang
    WHERE MANHOMSP = @MANHOMSP
);
GO
-- KIỂM THỬ FUNCTIONS 
SELECT dbo.fn_TinhGiaSauVAT(1000000, 0.1) AS GiaSauChietKhauVaVAT;   -- 990,000
SELECT dbo.fn_TinhGiaSauVAT(500000, NULL)  AS GiaChiCongVAT;        -- 550,000

SELECT * FROM dbo.ufn_TonKhoTheoNCC('NCC001');
SELECT * FROM dbo.ufn_MatHangTheoNhom('NHOM001');
go
--------------------------------
--------------------------------
-- 1) Thêm mặt hàng mới 
CREATE PROCEDURE sp_ThemMatHang
    @MAMH NVARCHAR(50),
    @TENMH NVARCHAR(100),
    @GIAMH FLOAT,
    @SOLUONGMH FLOAT,
    @MALOAISP NVARCHAR(20) = NULL,
    @MANHOMSP NVARCHAR(20) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRY
        INSERT INTO dbo.MatHang(MAMH, TENMH, GIAMH, SOLUONGMH, MALOAISP, MANHOMSP)
        VALUES(@MAMH, @TENMH, @GIAMH, @SOLUONGMH, @MALOAISP, @MANHOMSP);
    END TRY
    BEGIN CATCH
        DECLARE @msg NVARCHAR(4000) = ERROR_MESSAGE();
        RAISERROR('Lỗi khi thêm MatHang: %s', 16, 1, @msg);
    END CATCH
END
GO
----
EXEC sp_ThemMatHang 
        @MAMH = 'MH_TEST_001',
        @TENMH = N'Laptop Gaming Test 2025',
        @GIAMH = 28990000,
        @SOLUONGMH = 15,
        @MALOAISP = 'LSP001',
        @MANHOMSP = 'NHOM001';
SELECT *
FROM MatHang
WHERE MAMH = 'MH_TEST_001';

DELETE FROM MatHang
WHERE MAMH = 'MH_TEST_XOA';
-- 2) Cập nhật số lượng khi nhập kho
CREATE PROCEDURE sp_CapNhatSoLuongNhapKho
    @MAMH NVARCHAR(50),
    @SoLuongNhap INT
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRY
        UPDATE dbo.MatHang
        SET SOLUONGMH = ISNULL(SOLUONGMH,0) + @SoLuongNhap
        WHERE MAMH = @MAMH;
        IF @@ROWCOUNT = 0
            RAISERROR('Không tìm thấy MAMH = %s', 16, 1, @MAMH);
    END TRY
    BEGIN CATCH
        THROW;
    END CATCH
END
GO
------------
EXEC sp_CapNhatSoLuongNhapKho @MAMH = 'MH007', @SoLuongNhap = 20;
SELECT *
FROM MatHang
WHERE MAMH = 'MH007';

-- 3) Tìm kiếm mặt hàng 
CREATE PROCEDURE sp_TimKiemMatHang
    @tuKhoa NVARCHAR(100) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SELECT MAMH, TENMH, GIAMH, SOLUONGMH, MALOAISP, MANHOMSP
    FROM dbo.MatHang
    WHERE (@tuKhoa IS NULL OR TENMH LIKE '%' + @tuKhoa + '%' OR MAMH LIKE '%' + @tuKhoa + '%');
END
GO

EXEC sp_TimKiemMatHang N'laptop'; 
GO
-- 4) Thống kê doanh thu theo khoảng ngày (có tham số)
CREATE PROCEDURE sp_ThongKe_DoanhThu
    @FromDate DATETIME = NULL,
    @ToDate DATETIME = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SELECT YEAR(NGAYHD) AS Nam, MONTH(NGAYHD) AS Thang, SUM(THANHTIEN) AS TongDoanhThu, COUNT(MAHD) AS SoHoaDon
    FROM dbo.HoaDon
    WHERE (@FromDate IS NULL OR NGAYHD >= @FromDate) AND (@ToDate IS NULL OR NGAYHD <= @ToDate)
    GROUP BY YEAR(NGAYHD), MONTH(NGAYHD)
    ORDER BY YEAR(NGAYHD), MONTH(NGAYHD);
END
GO
EXEC sp_ThongKe_DoanhThu '2025-01-01', '2025-12-31';
GO

-- 5) Xóa nhân viên
CREATE PROCEDURE sp_XoaNhanVien
    @MANV NVARCHAR(20)
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRY
        IF EXISTS (SELECT 1 FROM dbo.HoaDon WHERE MANV = @MANV)
        BEGIN
            RAISERROR('Không thể xóa nhân viên vì đã có giao dịch/hoá đơn liên quan.', 16, 1);
            RETURN;
        END
        DELETE FROM dbo.NhanVien WHERE MANV = @MANV;
    END TRY
    BEGIN CATCH
        THROW;
    END CATCH
END
GO
------------
INSERT INTO dbo.NhanVien(MANV, TENNV, TENDANGNHAP, MATKHAU, MABP)
    VALUES('NV_TEST', N'Nhân viên Test', 'testnv', '123', 'BP001');
SELECT *
FROM NhanVien
WHERE MANV = 'NV_TEST';

    EXEC sp_XoaNhanVien 'NV_TEST';
GO


-- 6) Lấy danh sách khách hàng nợ lớn hơn X
CREATE PROCEDURE sp_KhachHangNoLonHon
    @SoTien FLOAT
AS
BEGIN
    SET NOCOUNT ON;
    -- Giả sử chưa có cột nợ; ta dùng tạm tổng tiền mua => khách hàng "nợ" tương tự doanh số
    SELECT kh.MAKH, kh.TENKH, SUM(h.THANHTIEN) AS TongNo
    FROM dbo.KhachHang kh
    JOIN dbo.HoaDon h ON kh.MAKH = h.MAKH
    GROUP BY kh.MAKH, kh.TENKH
    HAVING SUM(h.THANHTIEN) > ISNULL(@SoTien,0);
END
GO

EXEC sp_KhachHangNoLonHon 10000000;


---------------------------------------------------
----------------------------------------------------
-- Trigger 1: After INSERT on HoaDon -> ghi Audit + giảm tồn kho
CREATE TRIGGER trg_HoaDon_AfterInsert ON dbo.HoaDon
for INSERT
AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO Audit_Log(EventType, TableName, KeyValues, Detail, PerformedBy)
    SELECT 'INSERT', 'HoaDon', 'MAHD=' + i.MAHD, 'Tạo hóa đơn', SUSER_SNAME()
    FROM inserted i;
END
GO

-- Thêm hóa đơn mới
INSERT INTO dbo.HoaDon(MAHD, MAKH, NGAYHD, THANHTIEN)
VALUES('HD_TEST_001', 'KH001', GETDATE(), 500000);

-- Kiểm tra Audit_Log
SELECT * FROM Audit_Log WHERE TableName = 'HoaDon' AND KeyValues LIKE 'MAHD=HD_TEST_001';

-- Trigger 2: After INSERT on ChiTietHoaDon -> ghi log & cập nhật tồn kho 
CREATE TRIGGER trg_ChiTietHoaDon_AfterInsert ON dbo.ChiTietHoaDon
for INSERT
AS
BEGIN
    SET NOCOUNT ON;
    -- Ghi audit
    INSERT INTO Audit_Log(EventType, TableName, KeyValues, Detail, PerformedBy)
    SELECT 'INSERT', 'ChiTietHoaDon', 'MAHD=' + i.MAHD + ';MAMH=' + i.MAMH, 
           'ChiTietHoaDon: SL=' + CONVERT(NVARCHAR(50), i.SOLUONGHD), SUSER_SNAME()
    FROM inserted i;

    -- Cập nhật tồn kho 
    UPDATE m
    SET m.SOLUONGMH = CASE WHEN m.SOLUONGMH - i.SOLUONGHD >= 0 THEN m.SOLUONGMH - i.SOLUONGHD ELSE 0 END
    FROM dbo.MatHang m
    JOIN inserted i ON m.MAMH = i.MAMH;
END
GO

-- Thêm chi tiết hóa đơn
INSERT INTO dbo.ChiTietHoaDon(MAHD, MAMH, SOLUONGHD, DONGIAHD)
VALUES('HD_TEST_001', 'MH001', 5, 100000);

-- Kiểm tra Audit_Log
SELECT * FROM Audit_Log WHERE TableName = 'ChiTietHoaDon' AND KeyValues LIKE '%MAHD=HD_TEST_001%';

-- Kiểm tra tồn kho MatHang
SELECT MAMH, TENMH, SOLUONGMH FROM MatHang WHERE MAMH = 'MH001';

-- Trigger 3: After UPDATE on MatHang -> Audit thay đổi giá hoặc số lượng
CREATE TRIGGER trg_MatHang_AfterUpdate ON dbo.MatHang
for UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO Audit_Log(EventType, TableName, KeyValues, Detail, PerformedBy)
    SELECT 'UPDATE', 'MatHang',
           'MAMH=' + i.MAMH,
           'OldQty=' + CONVERT(NVARCHAR(50), d.SOLUONGMH) + ';NewQty=' + CONVERT(NVARCHAR(50), i.SOLUONGMH)
           + ';OldGia=' + CONVERT(NVARCHAR(50), d.GIAMH) + ';NewGia=' + CONVERT(NVARCHAR(50), i.GIAMH),
           SUSER_SNAME()
    FROM inserted i
    JOIN deleted d ON i.MAMH = d.MAMH;
END
GO

-- Cập nhật số lượng và giá
UPDATE MatHang
SET SOLUONGMH = SOLUONGMH + 10, GIAMH = GIAMH + 10000
WHERE MAMH = 'MH001';

-- Kiểm tra Audit_Log
SELECT * FROM Audit_Log WHERE TableName = 'MatHang' AND KeyValues = 'MAMH=MH001';

-- Trigger 4 : Tránh xóa Nhà cung cấp nếu có phiếu nhập
CREATE TRIGGER trg_NhaCungCap_BeforeDelete ON dbo.NhaCungCap
INSTEAD OF DELETE
AS
BEGIN
    SET NOCOUNT ON;
    IF EXISTS (
        SELECT 1 FROM deleted d
        JOIN dbo.PhieuNhap pn ON pn.MANCC = d.MANCC
    )
    BEGIN
        RAISERROR('Không thể xóa Nhà cung cấp vì tồn tại phiếu nhập liên quan.', 16, 1);
        RETURN;
    END
    DELETE FROM dbo.NhaCungCap WHERE MANCC IN (SELECT MANCC FROM deleted);
END
GO
-- Thử xóa nhà cung cấp có phiếu nhập
DELETE FROM NhaCungCap WHERE MANCC = 'NCC001'; -- Nếu NCC001 có phiếu nhập, sẽ lỗi

-- Xóa nhà cung cấp không có phiếu nhập
DELETE FROM NhaCungCap WHERE MANCC = 'NCC_TEST'; -- Thành công nếu không có phiếu nhập
----

-- Trigger 5: Mỗi nhóm sản phẩm phải có ít nhất 1 mặt hàng
CREATE TRIGGER trg_NhomSP_PhaiCoMatHang
ON MatHang
AFTER DELETE
AS
BEGIN
    IF EXISTS (
        SELECT MANHOMSP
        FROM NhomSanPham NS
        WHERE NOT EXISTS (
            SELECT 1 FROM MatHang MH WHERE MH.MANHOMSP = NS.MANHOMSP
        )
    )
    BEGIN
        ROLLBACK;
        RAISERROR('Mỗi nhóm sản phẩm phải có ít nhất một mặt hàng.', 16, 1);
        RETURN;
    END
END;

INSERT INTO MatHang(MAMH, TENMH, GIAMH, SOLUONGMH, MALOAISP, MANHOMSP)
VALUES('MH_TEST_XOA', N'Mặt hàng test', 100000, 2, 'LSP001', 'NHOM0016');

INSERT INTO NhomSanPham(MANHOMSP, TENNHOMSP)
VALUES( 'NHOM0016', 'Nhóm test');

DELETE FROM MatHang WHERE MAMH = 'MH_TEST_XOA';

INSERT INTO MatHang(MAMH, TENMH, GIAMH, SOLUONGMH, MALOAISP, MANHOMSP)
VALUES('MH_TEST_XOA_1', N'Mặt hàng test 1', 100000, 2, 'LSP001', 'NHOM001');
DELETE FROM MatHang WHERE MAMH = 'MH_TEST_XOA_1';


--------------------------------------
---------------------------------------
-- Tạo login + user 
CREATE LOGIN lg_quanly WITH PASSWORD = 'P@ssw0rdQuanLy2025';
CREATE LOGIN lg_nhanvien WITH PASSWORD = 'P@ssw0rdNV2025';
CREATE LOGIN lg_KeToan WITH PASSWORD = 'KeToan@2025#Secure';
GO

CREATE USER u_quanly FOR LOGIN lg_quanly;
CREATE USER u_nhanvien FOR LOGIN lg_nhanvien;
CREATE USER u_KeToan FOR LOGIN lg_KeToan;
GO

-- Tạo database roles
CREATE ROLE db_QuanLy;
CREATE ROLE db_NhanVien;
CREATE ROLE db_KeToan;
GO

-- Gán user vào role
EXEC sp_addrolemember 'db_QuanLy', 'u_quanly';
EXEC sp_addrolemember 'db_NhanVien', 'u_nhanvien';
EXEC sp_addrolemember 'db_KeToan', 'u_KeToan';
GO
-- 5. CẤP QUYỀN CHO QUẢN LÝ (gần như toàn quyền – nhưng vẫn an toàn)
-- Toàn quyền trên schema dbo (trừ quyền hệ thống nguy hiểm)
GRANT SELECT, INSERT, UPDATE, DELETE, EXECUTE, REFERENCES, VIEW DEFINITION ON SCHEMA::dbo TO db_QuanLy;
GRANT ALTER ON SCHEMA::dbo TO db_QuanLy;                   
GRANT CREATE TABLE, CREATE PROCEDURE, CREATE VIEW, CREATE FUNCTION, CREATE TYPE TO db_QuanLy;

GRANT ALTER ANY USER TO db_QuanLy;
GRANT ALTER ANY ROLE TO db_QuanLy;
GRANT VIEW ANY DEFINITION TO db_QuanLy;
GRANT SELECT ON SCHEMA::dbo TO db_QuanLy;
GO
-- 6. CẤP QUYỀN CHO NHÂN VIÊN BÁN HÀNG 
GRANT SELECT ON dbo.MatHang               TO db_NhanVien;
GRANT SELECT ON dbo.KhachHang             TO db_NhanVien;
GRANT SELECT ON dbo.vw_NhanVien_TheoBoPhan TO db_NhanVien; 
GRANT SELECT ON dbo.vw_DanhSachHoaDon_Details TO db_NhanVien;
GRANT SELECT ON dbo.vw_Top_MatHang_BanChay   TO db_NhanVien;

-- Chỉ được tạo hóa đơn mới + chi tiết
GRANT INSERT ON dbo.HoaDon           TO db_NhanVien;
GRANT INSERT ON dbo.ChiTietHoaDon    TO db_NhanVien;

-- Được cập nhật số lượng tồn kho khi bán 
GRANT UPDATE ON dbo.MatHang (SOLUONGMH) TO db_NhanVien;
-- Được thực thi các SP cần thiết cho bán hàng
GRANT EXECUTE ON dbo.sp_TimKiemMatHang    TO db_NhanVien;
GRANT EXECUTE ON dbo.sp_ThongKe_DoanhThu  TO db_NhanVien; 
GRANT EXECUTE ON dbo.sp_CapNhatSoLuongNhapKho  TO db_NhanVien; 


-- 7. CẤP QUYỀN CHO NHÂN VIÊN KẾ TOÁN
-- Kế toán chỉ được xem báo cáo
GRANT SELECT ON SCHEMA::dbo TO db_KeToan;
GRANT EXECUTE ON dbo.sp_ThongKe_DoanhThu      TO db_KeToan;
GRANT EXECUTE ON dbo.rp_DoanhThu_NhanVien TO db_KeToan;
GRANT SELECT ON dbo.vw_ThongKe_DoanhThu_TheoThang TO db_KeToan;
GRANT SELECT ON dbo.Audit_Log                  TO db_KeToan; 
GO

-- 8. Kiểm tra phân quyền 
EXECUTE AS LOGIN = 'lg_QuanLy';

SELECT N'QUẢN LÝ - Quyền trên các bảng chính' AS Section;

SELECT  
    'HoaDon'        AS TableName,
    HAS_PERMS_BY_NAME('dbo.HoaDon', 'OBJECT', 'SELECT') AS CanSelect,
    HAS_PERMS_BY_NAME('dbo.HoaDon', 'OBJECT', 'INSERT') AS CanInsert,
    HAS_PERMS_BY_NAME('dbo.HoaDon', 'OBJECT', 'UPDATE') AS CanUpdate,
    HAS_PERMS_BY_NAME('dbo.HoaDon', 'OBJECT', 'DELETE') AS CanDelete,
    HAS_PERMS_BY_NAME('dbo.HoaDon', 'OBJECT', 'EXECUTE') AS CanExecute;

SELECT  
    'MatHang'       AS TableName,
    HAS_PERMS_BY_NAME('dbo.MatHang', 'OBJECT', 'SELECT') AS CanSelect,
    HAS_PERMS_BY_NAME('dbo.MatHang', 'OBJECT', 'INSERT') AS CanInsert,
    HAS_PERMS_BY_NAME('dbo.MatHang', 'OBJECT', 'UPDATE') AS CanUpdate,
    HAS_PERMS_BY_NAME('dbo.MatHang', 'OBJECT', 'DELETE') AS CanDelete,
    HAS_PERMS_BY_NAME('dbo.MatHang', 'OBJECT', 'EXECUTE') AS CanExecute;

SELECT  
    'KhachHang'     AS TableName,
    HAS_PERMS_BY_NAME('dbo.KhachHang', 'OBJECT', 'SELECT') AS CanSelect,
    HAS_PERMS_BY_NAME('dbo.KhachHang', 'OBJECT', 'INSERT') AS CanInsert,
    HAS_PERMS_BY_NAME('dbo.KhachHang', 'OBJECT', 'UPDATE') AS CanUpdate,
    HAS_PERMS_BY_NAME('dbo.KhachHang', 'OBJECT', 'DELETE') AS CanDelete;

REVERT;
GO
----------------------------------------------------------
------------------------------------------------------------
EXECUTE AS LOGIN = 'lg_NhanVien';

SELECT N'NHÂN VIÊN - Quyền trên các bảng chính' AS Section;

SELECT 'HoaDon' AS TableName,
       HAS_PERMS_BY_NAME('dbo.HoaDon', 'OBJECT', 'SELECT') AS CanSelect,
       HAS_PERMS_BY_NAME('dbo.HoaDon', 'OBJECT', 'INSERT') AS CanInsert,
       HAS_PERMS_BY_NAME('dbo.HoaDon', 'OBJECT', 'UPDATE') AS CanUpdate,
       HAS_PERMS_BY_NAME('dbo.HoaDon', 'OBJECT', 'DELETE') AS CanDelete;

SELECT 'MatHang' AS TableName,
       HAS_PERMS_BY_NAME('dbo.MatHang', 'OBJECT', 'SELECT') AS CanSelect,
       HAS_PERMS_BY_NAME('dbo.MatHang', 'OBJECT', 'INSERT') AS CanInsert,
       HAS_PERMS_BY_NAME('dbo.MatHang', 'OBJECT', 'UPDATE') AS CanUpdate,
       HAS_PERMS_BY_NAME('dbo.MatHang', 'OBJECT', 'DELETE') AS CanDelete;

SELECT 'KhachHang' AS TableName,
       HAS_PERMS_BY_NAME('dbo.KhachHang', 'OBJECT', 'SELECT') AS CanSelect,
       HAS_PERMS_BY_NAME('dbo.KhachHang', 'OBJECT', 'INSERT') AS CanInsert,
       HAS_PERMS_BY_NAME('dbo.KhachHang', 'OBJECT', 'UPDATE') AS CanUpdate,
       HAS_PERMS_BY_NAME('dbo.KhachHang', 'OBJECT', 'DELETE') AS CanDelete;

-- Kiểm tra quyền trên VIEW
SELECT  
    'vw_NhanVien_ThongTin' AS ViewName,
    HAS_PERMS_BY_NAME('dbo.vw_NhanVien_ThongTin', 'OBJECT', 'SELECT') AS CanSelect;
SELECT 'vw_DanhSachHoaDon_Details' AS ViewName,
       HAS_PERMS_BY_NAME('dbo.vw_DanhSachHoaDon_Details', 'OBJECT', 'SELECT') AS CanSelect;

-- Kiểm tra SP
SELECT  
    'sp_TimKiemMatHang' AS SPName,
    HAS_PERMS_BY_NAME('dbo.sp_TimKiemMatHang', 'OBJECT', 'EXECUTE') AS CanExecute;

SELECt  
    'sp_ThongKe_DoanhThu' AS SPName,
    HAS_PERMS_BY_NAME('dbo.sp_ThongKe_DoanhThu', 'OBJECT', 'EXECUTE') AS CanExecute;

REVERT;
GO

--------------------------------------------------------------
----------------------------------------------------------------
EXECUTE AS LOGIN = 'lg_KeToan';

SELECT N'KẾ TOÁN - Quyền trên các bảng & báo cáo' AS Section;

SELECT  
    'HoaDon' AS TableName,
    HAS_PERMS_BY_NAME('dbo.HoaDon', 'OBJECT', 'SELECT') AS CanSelect,
    HAS_PERMS_BY_NAME('dbo.HoaDon', 'OBJECT', 'INSERT') AS CanInsert,
    HAS_PERMS_BY_NAME('dbo.HoaDon', 'OBJECT', 'UPDATE') AS CanUpdate,
    HAS_PERMS_BY_NAME('dbo.HoaDon', 'OBJECT', 'DELETE') AS CanDelete;

-- Quyền xem Audit
SELECT  
    'Audit_Log' AS TableName,
    HAS_PERMS_BY_NAME('dbo.Audit_Log', 'OBJECT', 'SELECT') AS CanSelect;

-- Quyền execute SP
SELECT  
    'sp_ThongKe_DoanhThu' AS SPName,
    HAS_PERMS_BY_NAME('dbo.sp_ThongKe_DoanhThu', 'OBJECT', 'EXECUTE') AS CanExecute;

SELECT  
    'sp_DoanhThu_NhanVien_Thang' AS SPName,
    HAS_PERMS_BY_NAME('dbo.sp_DoanhThu_NhanVien_Thang', 'OBJECT', 'EXECUTE') AS CanExecute;

REVERT;
GO



